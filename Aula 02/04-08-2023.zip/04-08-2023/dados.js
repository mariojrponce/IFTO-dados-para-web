const texto=`<livraria>
    <livro>
        <titulo>História do Brasil</titulo>
        <autor>Carlos Augusto</autor>
        <ano>2010</ano>
        <preco>150</preco>
    </livro>
    <livro>
        <titulo>Geografia</titulo>
        <autor>Mônica</autor>
        <ano>2015</ano>
        <preco>130</preco>
    </livro>
    <livro>
        <titulo>Matemática</titulo>
        <autor>Silva Junior</autor>
        <ano>2020</ano>
        <preco>100</preco>
    </livro>
</livraria>`;